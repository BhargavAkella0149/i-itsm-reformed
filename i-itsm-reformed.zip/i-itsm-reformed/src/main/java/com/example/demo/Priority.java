package com.example.demo;

public enum Priority { P1, P2, P3, P4 }
